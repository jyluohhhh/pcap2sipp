

This application creates sipp scenarios based in pcap traces.

*****************************************
REQUIREMENTS
*****************************************
Pre-requisites to compile pcap2sipp

     libpcap-dev
     libnet-dev
     tcpdump

*****************************************
COMPILE
*****************************************
Just run the make command:

     make all
